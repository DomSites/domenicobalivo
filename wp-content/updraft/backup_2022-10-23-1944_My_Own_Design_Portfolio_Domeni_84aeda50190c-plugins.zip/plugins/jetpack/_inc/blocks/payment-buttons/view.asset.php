<?php return array('dependencies' => array('wp-polyfill'), 'version' => '9b3c4f5365c995af1539');
