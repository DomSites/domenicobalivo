<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '73306283e22190eaa6bc');
