<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '15c29062b4917da52656');
