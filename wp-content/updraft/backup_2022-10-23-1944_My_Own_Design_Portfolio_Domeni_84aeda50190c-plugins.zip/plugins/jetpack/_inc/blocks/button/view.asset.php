<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'c3d509af36ff361194ae');
