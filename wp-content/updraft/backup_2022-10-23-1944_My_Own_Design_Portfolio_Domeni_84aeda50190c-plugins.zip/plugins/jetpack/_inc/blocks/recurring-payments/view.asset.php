<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '6efa01627f443efeaf25');
