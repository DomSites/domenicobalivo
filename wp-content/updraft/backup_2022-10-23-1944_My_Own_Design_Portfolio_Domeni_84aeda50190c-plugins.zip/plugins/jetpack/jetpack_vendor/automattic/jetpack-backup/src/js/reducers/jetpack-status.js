const jetpackStatus = ( state = {} ) => {
	return state;
};

export default jetpackStatus;
