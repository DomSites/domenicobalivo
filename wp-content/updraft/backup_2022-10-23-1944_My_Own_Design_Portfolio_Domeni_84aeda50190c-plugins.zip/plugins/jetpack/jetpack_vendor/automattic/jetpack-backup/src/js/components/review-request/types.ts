export type ReviewRequestBaseProps = {
	cta: string;
	onClick: () => void;
	requestReason: string;
	reviewText: string;
};
