# calypsoify
WordPress plugin for redesigning WP-Admin plugin screens to match Calypso.

![](https://cldup.com/jxE-hrHGgj.png)
