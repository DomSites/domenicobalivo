<?php
define("AJXP_VERSION", "8.0.1");
define("AJXP_VERSION_DATE", "2017-06-08");
define("AJXP_VERSION_REV", "62d4c99");
define("AJXP_VERSION_DB", "68");
