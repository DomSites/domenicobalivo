<?php
$mess = array(
    "1" => "Convite",
    "1p" => "Convites",
    "2" => "Arquivo Compartilhado",
    "2p" => "Arquivos Compartilhados",
    "3" => "Compartilhamento Inválido",
    "3p" => "Compartilhamentos Inválidos",
    "4" => "pendente",
    "5" => "erro",
    "6" => "Arquivos compartilhados comigo",
    "7" => "Estes são arquivos que pessoas compartilharam com você. Diretórios são acessíveis diretamente pelo painel esquerdo.",
    "8" => "Filtragem Rápida",
    "9" => "Por nome de arquivo",
    "10" => "Por Tipo",
    "11" => "Limpar",
    "12" => "Arquivos Compartilhados",
    "13" => "Arquivos compartilhados comigo por outros usuários",
    "14" => "Copiar para uma área de trabalho",
    "15" => "Copiar arquivo para outra área de trabalho sua",
    "16" => "Total",
    "17" => "Novo"
);
