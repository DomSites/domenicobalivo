<?php
$mess = array(
    "1" => "Invitación",
    "1p" => "Invitaciones",
    "2" => "Archivo Compartido",
    "2p" => "Archivos Compartidos",
    "3" => "Intercambio Inválido",
    "3p" => "Intercambios Inválidos",
    "4" => "pendiente",
    "5" => "error",
    "6" => "Archivos compartidos conmigo",
    "7" => "Estos son los archivos únicos que han compartido contigo. Las carpetas son accesibles desde el panel de la izquierda.",
    "8" => "Filtrado Rápido",
    "9" => "Por nombre de archivo",
    "10" => "Por tipo",
    "11" => "Limpiar",
    "12" => "Archivos Compartidos",
    "13" => "Archivos compartidos conmigo",
    "14" => "Copiar a workspace",
    "15" => "Copiar archivo a otro de tus workspaces",
    "16" => "Total",
    "17" => "Nuevo"
);
