<?php
$mess = array(
    "1" => "Invito",
    "1p" => "Inviti",
    "2" => "File Condiviso",
    "2p" => "File Condivisi",
    "3" => "Condivisione Errata",
    "3p" => "Condivisioni Errate",
    "4" => "pendente",
    "5" => "errore",
    "6" => "File condivisi con me",
    "7" => "Questi sono i singoli file che le persone hanno condiviso con te. Le cartelle sono accessibili direttamente dal pannello di sinistra.",
    "8" => "Filtro Rapido",
    "9" => "Per nome file",
    "10" => "Per Tipo",
    "11" => "Pulisci",
    "12" => "File Condivisi",
    "13" => "File condivisi con me dagli altri utenti",
    "14" => "Copia in un workspace",
    "15" => "Copia il file in un altro dei tuoi workspace",
    "16" => "Totale",
    "17" => "Nuovo"
);
