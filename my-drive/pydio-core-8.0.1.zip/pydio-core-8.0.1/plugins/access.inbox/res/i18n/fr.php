<?php
$mess = array(
    "1" => "Invitation",
    "1p" => "Invitations",
    "2" => "Fichier Partagé",
    "2p" => "Fichiers Partagés",
    "3" => "Partage Invalid",
    "3p" => "Partages Invalides",
    "4" => "en attente",
    "5" => "erreur",
    "6" => "Fichiers partagés avec moi",
    "7" => "Les fichiers que les autres utilisateurs ont partagé avec vous. Les répertoires sont accessibles directement depuis le menu de gauche.",
    "8" => "Filtrage rapide",
    "9" => "Par nom de fichier",
    "10" => "Par type",
    "11" => "Vider",
    "12" => "Fichiers Partagés",
    "13" => "Les fichiers partagés avec moi par d'autres utilisateurs",
    "14" => "Copier dans un workspace",
    "15" => "Copier dans un autre de vos workspaces",
    "16" => "Total",
    "17" => "Nouveaux"
);
